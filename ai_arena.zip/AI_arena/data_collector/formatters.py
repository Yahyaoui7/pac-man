import json
from typing import TextIO

from AI_arena.data_collector.models import TrainingSample

DIRECTION_INDEX = {"UP": 0, "DOWN": 1, "LEFT": 2, "RIGHT": 3}


class MLPFormatter:

    @staticmethod
    def format_line(sample: TrainingSample, ghost_idx: int) -> dict:
        w = sample.metadata["maze_width"]
        h = sample.metadata["maze_height"]
        px, py = sample.world.player_position
        ghost = sample.ghosts[ghost_idx]
        gx, gy = ghost.position

        # --- Feature 1-2: Relative X/Y to player (directional awareness) ---
        rel_x = (gx - px) / max(w - 1, 1)
        rel_y = (gy - py) / max(h - 1, 1)

        # --- Feature 3: BFS path length (navigation / wall separation) ---
        bfs_dist = (
            ghost.path_length / max(w + h, 1)
            if ghost.path_length is not None
            else 1.0
        )

        # --- Feature 4-7: Ghost local topology (available moves) ---
        ghost_up = float("UP" in ghost.available_moves)
        ghost_down = float("DOWN" in ghost.available_moves)
        ghost_left = float("LEFT" in ghost.available_moves)
        ghost_right = float("RIGHT" in ghost.available_moves)

        # --- Feature 8-11: Player escape topology (player's available moves) ---
        player_moves = sample.world.player_available_moves
        player_up = float("UP" in player_moves)
        player_down = float("DOWN" in player_moves)
        player_left = float("LEFT" in player_moves)
        player_right = float("RIGHT" in player_moves)

        # --- Feature 12-14: Mode one-hot (Chase / Scatter / Frightened) ---
        mode_chase = float(ghost.mode == "CHASE")
        mode_scatter = float(ghost.mode == "SCATTER")
        mode_frightened = float(ghost.mode == "FRIGHTENED")

        # --- Feature 15: Frightened timer remaining (urgency / ambush timing) ---
        max_frightened_time = sample.metadata.get("max_frightened_time", 10)
        fright_timer = (
            ghost.frightened_timer / max_frightened_time
            if hasattr(ghost, "frightened_timer")
            else 0.0
        )

        # --- Feature 16-19: Player facing direction (trajectory prediction) ---
        # player_facing = (
        #    sample.world.player_facing
        #    if hasattr(sample.world, "player_facing")
        #    else None
        # )
        # player_face_up = float(player_facing == "UP")
        # player_face_down = float(player_facing == "DOWN")
        # player_face_left = float(player_facing == "LEFT")
        # player_face_right = float(player_facing == "RIGHT")

        features = [  # one ghost
            px,  # player X
            py,  # player y
            gx,  # ghost x
            gy,  # ghost y
            rel_x,  # relative dist x (player_x - ghost_x)
            rel_y,  # relative dist y (player_y - ghost_y)
            bfs_dist,  #
            ghost_up,  #
            ghost_down,  #
            ghost_left,  #
            ghost_right,  #
            player_up,  #
            player_down,  #
            player_left,  #
            player_right,  #
            mode_chase,  #
            mode_frightened,  #
            fright_timer,  #
            # player_face_up,  #
            # player_face_down,  #
            # player_face_left,  #
            # player_face_right,  #
        ]

        first_dir = ghost.bfs_directions[0] if ghost.bfs_directions else None
        label = DIRECTION_INDEX.get(first_dir, -1)

        return {"features": features, "label": label}


class CNNFormatter:
    """Formats a TrainingSample into grid-based data for CNN training.

    Placeholder — will be expanded with maze/pellet/ghost overlay grids.
    """

    @staticmethod
    def format_line(sample: TrainingSample, ghost_idx: int) -> dict:
        ghost = sample.ghosts[ghost_idx]
        first_dir = ghost.bfs_directions[0] if ghost.bfs_directions else None
        return {
            "maze": sample.world.maze,
            "pellets": sample.world.pellets,
            "player_position": list(sample.world.player_position),
            "ghost_position": list(ghost.position),
            "ghost_name": ghost.name,
            "label": DIRECTION_INDEX.get(first_dir, -1),
        }


class StreamWriter:
    """Appends JSONL lines to a file handle. One write per line, no buffering."""

    def __init__(self, fh: TextIO) -> None:
        self.fh = fh

    def write_line(self, record: dict) -> None:
        self.fh.write(json.dumps(record) + "\n")
