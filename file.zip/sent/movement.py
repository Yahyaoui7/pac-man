from collections import deque
from typing import List, Optional, Any, Tuple

from src.graphics.entitys.entity import Entity
from src.logic.config import CELL_SIZE, EAST, NORTH, SOUTH, WEST
import random
import os
import time
import torch


class MovementSystem:
    """Controls movement for player and ghosts."""

    def __init__(self, maze: List[List[int]]) -> None:
        """Store the maze so we can check walls."""
        self.maze = maze
        self.rng = random.Random()
        self.pattern_42: Optional[List[Tuple[int, int]]] = None

        self.mlp_model = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "AI_arena", "mlp_model.pth")
        
        if os.path.exists(model_path):
            try:
                from AI_arena.MLP import MLP
                start_time = time.time()
                self.mlp_model = MLP(21, [128, 64, 32], 4).to(self.device)
                self.mlp_model.load_state_dict(torch.load(model_path, map_location=self.device, weights_only=True))
                self.mlp_model.eval()
                load_time = time.time() - start_time
                print(f"Successfully loaded AI model for ghosts in {load_time:.4f} seconds!")
            except Exception as e:
                print(f"Failed to load AI model: {e}")

    def set_direction(self, entity: Entity, direction: str) -> None:
        """Set entity direction and convert it to grid_y/grid_x movement."""
        entity.direction = direction

        if direction == "LEFT":
            entity.grid_y_direction = 0
            entity.grid_x_direction = -1
        elif direction == "RIGHT":
            entity.grid_y_direction = 0
            entity.grid_x_direction = 1
        elif direction == "UP":
            entity.grid_y_direction = -1
            entity.grid_x_direction = 0
        elif direction == "DOWN":
            entity.grid_y_direction = 1
            entity.grid_x_direction = 0

    def is_centered(self, entity: Entity) -> bool:
        tolerance = 5

        cell_grid_x = int(entity.x // CELL_SIZE)
        cell_grid_y = int(entity.y // CELL_SIZE)

        center_x = cell_grid_x * CELL_SIZE + CELL_SIZE // 2
        center_y = cell_grid_y * CELL_SIZE + CELL_SIZE // 2

        if (
            abs(entity.x - center_x) <= tolerance
            and abs(entity.y - center_y) <= tolerance
        ):
            return True
        else:
            return False

    def update_cell_position(self, entity: Entity) -> None:
        """Update grid_y/grid_x using the current pixel position x/y."""
        entity.grid_y = int(entity.y // CELL_SIZE)
        entity.grid_x = int(entity.x // CELL_SIZE)

    def can_move(self, grid_y: int, grid_x: int, direction: str) -> bool:
        directions = {
            "LEFT": (0, -1),
            "RIGHT": (0, 1),
            "UP": (-1, 0),
            "DOWN": (1, 0),
        }

        if direction not in directions:
            return False

        if not (0 <= grid_y < len(self.maze)) or not (0 <= grid_x < len(self.maze[0])):
            return False

        d_grid_y, d_grid_x = directions[direction]
        next_y = grid_y + d_grid_y
        next_x = grid_x + d_grid_x

        if not (0 <= next_y < len(self.maze)):
            return False

        if not (0 <= next_x < len(self.maze[0])):
            return False

        next_cell = (next_y, next_x)

        if self.pattern_42 and next_cell in self.pattern_42:
            return True

        cell = self.maze[grid_y][grid_x]

        if direction == "LEFT":
            return not (cell & WEST)
        if direction == "RIGHT":
            return not (cell & EAST)
        if direction == "UP":
            return not (cell & NORTH)
        if direction == "DOWN":
            return not (cell & SOUTH)

        return False

    def is_opposite_direction(self, entity: Entity) -> bool:
        opposite_direction = {
            "LEFT": "RIGHT",
            "RIGHT": "LEFT",
            "UP": "DOWN",
            "DOWN": "UP",
        }

        d = entity.direction
        nd = entity.next_direction
        if d is None or nd is None:
            return False

        return d in opposite_direction and opposite_direction[d] == nd

    def update_entity(self, entity: Entity) -> None:
        """Move an entity by pixels, only change direction at cell center."""
        if self.is_opposite_direction(entity):
            assert entity.next_direction is not None
            self.set_direction(entity, entity.next_direction)
            entity.next_direction = None

        if self.is_centered(entity):
            self.update_cell_position(entity)

            if entity.next_direction is not None:
                if self.can_move(
                    entity.grid_y,
                    entity.grid_x,
                    entity.next_direction,
                ):
                    self.set_direction(entity, entity.next_direction)
                    entity.next_direction = None

            if entity.direction is None:
                return

            if not self.can_move(
                entity.grid_y,
                entity.grid_x,
                entity.direction,
            ):
                return

        entity.x += entity.grid_x_direction * entity.speed
        entity.y += entity.grid_y_direction * entity.speed

    # ----------------------------
    # NOT EDIBLE GHOST MOVEMENT
    # Ghost chases player using BFS
    # ----------------------------

    def get_neighbors(self, grid_y: int, grid_x: int) -> list[tuple[int, int]]:
        """Return all cells the ghost can move to from current cell."""
        neighbors = []

        directions = {
            "LEFT": (0, -1),
            "RIGHT": (0, 1),
            "UP": (-1, 0),
            "DOWN": (1, 0),
        }

        for direction, (d_grid_y, d_grid_x) in directions.items():
            next_cell = (grid_y + d_grid_y, grid_x + d_grid_x)
            if self.can_move(grid_y, grid_x, direction):
                neighbors.append(next_cell)

        return neighbors

    def bfs_path(
        self, start: tuple[int, int], target: tuple[int, int]
    ) -> list[tuple[int, int]]:
        """Find the shortest path from ghost to player."""
        queue = deque([start])
        visited = {start}
        parent: dict[tuple[int, int], tuple[int, int]] = {}

        while queue:
            current = queue.popleft()

            if current == target:
                path = []
                while current != start:
                    path.append(current)
                    current = parent[current]
                path.append(start)
                path.reverse()
                return path

            for neighbor in self.get_neighbors(current[0], current[1]):
                if neighbor not in visited:
                    visited.add(neighbor)
                    parent[neighbor] = current
                    queue.append(neighbor)

        return []

    def direction_to_next_cell(
        self,
        current: tuple[int, int],
        next_cell: tuple[int, int],
    ) -> str | None:
        """Convert next cell into a direction string."""
        grid_y, grid_x = current
        next_grid_y, next_grid_x = next_cell

        if next_grid_y == grid_y and next_grid_x == grid_x - 1:
            return "LEFT"
        if next_grid_y == grid_y and next_grid_x == grid_x + 1:
            return "RIGHT"
        if next_grid_y == grid_y - 1 and next_grid_x == grid_x:
            return "UP"
        if next_grid_y == grid_y + 1 and next_grid_x == grid_x:
            return "DOWN"

        return None

    def move_inside_prison(self, ghost: Any) -> None:
        self.pattern_42 = ghost.prison_cells

        try:
            if self.is_centered(ghost):
                self.update_cell_position(ghost)
                if not ghost.prison_cells:
                    return
                high_cell = min(ghost.prison_cells, key=lambda cell: cell[0])
                low_cell = max(ghost.prison_cells, key=lambda cell: cell[0])

                current_cell = (ghost.grid_y, ghost.grid_x)

                if ghost.prison_target is None:
                    ghost.prison_target = low_cell

                if current_cell == ghost.prison_target:
                    if ghost.prison_target == low_cell:
                        ghost.prison_target = high_cell
                    else:
                        ghost.prison_target = low_cell

                path = self.bfs_path(current_cell, ghost.prison_target)

                if len(path) >= 2:
                    next_cell = path[1]
                    direction = self.direction_to_next_cell(
                        current_cell,
                        next_cell,
                    )

                    if direction is not None:
                        self.set_direction(ghost, direction)

            self.update_entity(ghost)

        finally:
            self.pattern_42 = None

    def _navigate_bfs(
        self,
        ghost: Any,
        target_grid_y: int,
        target_grid_x: int,
    ) -> None:
        """Move ghost toward target using BFS pathfinding."""
        if self.is_centered(ghost):
            self.update_cell_position(ghost)
            start = (ghost.grid_y, ghost.grid_x)
            target = (target_grid_y, target_grid_x)

            path = self.bfs_path(start, target)

            if len(path) >= 2:
                next_cell = path[1]
                direction = self.direction_to_next_cell(start, next_cell)

                if direction is not None:
                    self.set_direction(ghost, direction)

        self.update_entity(ghost)

    def update_ghost_to_target(
        self,
        ghost: Any,
        target_y: int,
        target_x: int,
    ) -> None:
        self.pattern_42 = ghost.prison_cells

        try:
            self._navigate_bfs(ghost, target_y, target_x)
        finally:
            self.pattern_42 = None

    def update_bfs_ghost(self, ghost: Any, player: Any) -> None:
        """Move ghost toward player when ghost is not edible."""
        self.pattern_42 = None
        self._navigate_bfs(ghost, player.grid_y, player.grid_x)

    def build_training_sample(self, ghost_idx: int, em: Any) -> Any:
        from AI_arena.data_collector.models import TrainingSample, WorldState, GhostState
        
        width = len(self.maze[0])
        height = len(self.maze)
        
        player = em.player
        player_pos = (player.grid_x, player.grid_y)
        
        player_available_moves = []
        for d in ["UP", "DOWN", "LEFT", "RIGHT"]:
            if self.can_move(player.grid_y, player.grid_x, d):
                player_available_moves.append(d)
                
        world = WorldState(
            maze=self.maze,
            pellets=em.pellets,
            player_position=player_pos,
            player_direction=player.direction if player.direction else "NONE",
            player_powered=player.powered_mode is not None,
            remaining_pellets=sum(cell == 1 for row in em.pellets for cell in row),
            remaining_super_pellets=sum(cell == 2 for row in em.pellets for cell in row),
            player_available_moves=player_available_moves
        )
        
        ghost_states = []
        for g in em.ghosts:
            gx, gy = g.grid_x, g.grid_y
            
            chase_result = self.get_bfs_next_move((gy, gx), player_pos)
            if chase_result is not None:
                chase_directions, path_length = chase_result
            else:
                chase_directions, path_length = [], 0
                
            available_moves = []
            for d in ["UP", "DOWN", "LEFT", "RIGHT"]:
                if self.can_move(gy, gx, d):
                    available_moves.append(d)
                    
            mode = "FRIGHTENED" if g.is_edible else "CHASE"
            manhattan_dist = abs(gx - player_pos[0]) + abs(gy - player_pos[1])
            
            local_pellet_count = 0
            radius = 3
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    ny, nx = gy + dy, gx + dx
                    if 0 <= ny < height and 0 <= nx < width:
                        local_pellet_count += em.pellets[ny][nx]
            
            g_state = GhostState(
                name=g.name,
                position=(gx, gy),
                mode=mode,
                distance_to_player=path_length,
                bfs_path=[],
                bfs_directions=chase_directions,
                path_length=path_length,
                available_moves=available_moves,
                manhattan_distance=manhattan_dist,
                local_pellet_count=local_pellet_count,
                num_exits=len(available_moves),
                frightened_timer=g.frightened_timer
            )
            ghost_states.append(g_state)
            
        return TrainingSample(
            metadata={"maze_width": width, "maze_height": height},
            world=world,
            ghosts=ghost_states
        )

    def update_mlp_ghost(self, ghost: Any, em: Any) -> None:
        """Move ghost using the MLP AI model."""
        if self.mlp_model is None:
            return self.update_bfs_ghost(ghost, em.player)
            
        self.pattern_42 = None
        if self.is_centered(ghost):
            self.update_cell_position(ghost)
            
            if ghost.next_direction is None:
                try:
                    ghost_idx = em.ghosts.index(ghost)
                except ValueError:
                    ghost_idx = 0
                    
                from AI_arena.data_collector.formatters import MLPFormatter
                
                inference_start = time.time()
                
                sample = self.build_training_sample(ghost_idx, em)
                formatted = MLPFormatter.format_line(sample, ghost_idx, single_ghost=True)
                
                features = formatted["features"]
                x = torch.tensor([features], dtype=torch.float32).to(self.device)
                
                with torch.no_grad():
                    pred = self.mlp_model(x)
                    
                direction_idx = torch.argmax(pred, dim=1).item()
                index_to_dir = {0: "UP", 1: "DOWN", 2: "LEFT", 3: "RIGHT"}
                target_direction = index_to_dir.get(direction_idx, "UP")
                
                inference_time = time.time() - inference_start
                print(f"Ghost '{ghost.name}' AI Action: {target_direction} | Inference Time: {inference_time:.5f}s")
                
                if self.can_move(ghost.grid_y, ghost.grid_x, target_direction):
                    ghost.next_direction = target_direction
                else:
                    self._navigate_bfs(ghost, em.player.grid_y, em.player.grid_x)

        self.update_entity(ghost)

    # ----------------------------
    # EDIBLE GHOST MOVEMENT
    # Ghost runs away from player
    # ----------------------------

    def get_zone(self, grid_y: int, grid_x: int) -> str:
        middle_grid_y = len(self.maze) // 2
        middle_grid_x = len(self.maze[0]) // 2
        if grid_y < middle_grid_y and grid_x < middle_grid_x:
            return "TOP_LEFT"
        if grid_y < middle_grid_y and grid_x >= middle_grid_x:
            return "TOP_RIGHT"
        if grid_y >= middle_grid_y and grid_x < middle_grid_x:
            return "BOTTOM_LEFT"

        return "BOTTOM_RIGHT"

    def get_zone_bounds(self, zone: str) -> Tuple[
        Tuple[int, int],
        Tuple[int, int],
    ]:
        middle_grid_y = len(self.maze) // 2
        middle_grid_x = len(self.maze[0]) // 2
        max_grid_y = len(self.maze) - 1
        max_grid_x = len(self.maze[0]) - 1

        if zone == "TOP_LEFT":
            return (0, middle_grid_y - 1), (0, middle_grid_x - 1)
        if zone == "TOP_RIGHT":
            return (0, middle_grid_y - 1), (middle_grid_x, max_grid_x)
        if zone == "BOTTOM_LEFT":
            return (middle_grid_y, max_grid_y), (0, middle_grid_x - 1)
        return (middle_grid_y, max_grid_y), (middle_grid_x, max_grid_x)

    def is_valid_cell(self, grid_y: int, grid_x: int) -> bool:
        for direction in ["LEFT", "RIGHT", "UP", "DOWN"]:
            if self.can_move(grid_y, grid_x, direction):
                return True

        return False

    def choose_runaway_target_by_zone(
        self,
        player: Any,
    ) -> Optional[Tuple[int, int]]:
        player_zone = self.get_zone(player.grid_y, player.grid_x)

        zones = [
            "TOP_LEFT",
            "TOP_RIGHT",
            "BOTTOM_LEFT",
            "BOTTOM_RIGHT",
        ]

        safe_zones = []

        for zone in zones:
            if zone != player_zone:
                safe_zones.append(zone)

        while safe_zones:
            random_zone = self.rng.choice(safe_zones)

            (
                grid_y_min,
                grid_y_max,
            ), (
                grid_x_min,
                grid_x_max,
            ) = self.get_zone_bounds(random_zone)

            valid_cells = []

            for grid_y in range(grid_y_min, grid_y_max + 1):
                for grid_x in range(grid_x_min, grid_x_max + 1):
                    if self.is_valid_cell(grid_y, grid_x):
                        valid_cells.append((grid_y, grid_x))

            if valid_cells:
                return self.rng.choice(valid_cells)

            safe_zones.remove(random_zone)

        return None

    def update_runaway_ghost(self, ghost: Any, player: Any) -> None:
        """Move edible ghost away from the player using fixed random target."""

        if self.is_centered(ghost):
            self.update_cell_position(ghost)

            if ghost.runaway_target is None:
                ghost.runaway_target = self.choose_runaway_target_by_zone(
                    player,
                )

            if ghost.runaway_target == (ghost.grid_y, ghost.grid_x):
                ghost.runaway_target = self.choose_runaway_target_by_zone(
                    player,
                )

            if ghost.runaway_target is not None:
                start = (ghost.grid_y, ghost.grid_x)
                path = self.bfs_path(
                    start,
                    ghost.runaway_target,
                )

                if len(path) >= 2:
                    next_cell = path[1]
                    direction = self.direction_to_next_cell(start, next_cell)

                    if direction is not None:
                        self.set_direction(ghost, direction)
                else:
                    ghost.runaway_target = None

        self.update_entity(ghost)

    def get_bfs_next_move(
        self,
        start: tuple[int, int],
        target: tuple[int, int],
    ) -> tuple[list[str | None], int] | None:
        """Return (directions_list, path_length) from start (x,y) to target (x,y).

        directions_list[i] is the direction from path[i] to path[i+1].
        The first direction is the immediate next move.
        """
        start_yx = (start[1], start[0])
        target_yx = (target[1], target[0])
        path = self.bfs_path(start_yx, target_yx)
        if len(path) < 2:
            return None
        res = []
        for pt in range(len(path) - 1):
            res.append(self.direction_to_next_cell(path[pt], path[pt + 1]))
        return res, len(path)

    def get_runaway_next_move(
        self,
        ghost_position: tuple[int, int],
        player_position: tuple[int, int],
    ) -> tuple[list[str | None], int] | None:
        ghost_yx = (ghost_position[1], ghost_position[0])
        player_yx = (player_position[1], player_position[0])

        target = self.choose_runaway_target(player_yx)
        if target is None:
            return None

        path = self.bfs_path(ghost_yx, target)
        if len(path) < 2:
            return None
        res = []
        for pt in range(len(path) - 1):
            res.append(self.direction_to_next_cell(path[pt], path[pt + 1]))
        return res, len(path)

    def choose_runaway_target(
        self,
        player_yx: tuple[int, int],
    ) -> Optional[Tuple[int, int]]:
        player_zone = self.get_zone(player_yx[0], player_yx[1])

        zones = ["TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"]
        safe_zones = [z for z in zones if z != player_zone]

        while safe_zones:
            random_zone = self.rng.choice(safe_zones)
            (y_min, y_max), (x_min, x_max) = self.get_zone_bounds(random_zone)

            valid_cells = []
            for gy in range(y_min, y_max + 1):
                for gx in range(x_min, x_max + 1):
                    if self.is_valid_cell(gy, gx):
                        valid_cells.append((gy, gx))

            if valid_cells:
                return self.rng.choice(valid_cells)
            safe_zones.remove(random_zone)

        return None
